# NMB WhatsApp Banking API — MongoDB demo

A Spring Boot prototype using fictional data and mock responses only.

## Guardrails
- No NMB production integration, live WhatsApp API, or real money transfers.
- Use fictional data only; do not connect to real customer records.
- The first `mvnw.cmd` run may download Maven 3.9.9. This does not install Maven system-wide or change PATH, but company policy may prohibit downloads. Ask IT for an approved Maven runtime if downloads are restricted.
- Demo Basic Auth credentials are for local testing only, not production.

## Requirements
- JDK 21
- An approved MongoDB URI
- Permission for Maven/dependency downloads, or an IT-provided build environment

## Windows PowerShell
From the extracted project root:
```powershell
java -version
.\mvnw.cmd -version
.\mvnw.cmd validate
.\mvnw.cmd test
.\mvnw.cmd spring-boot:run
```
If policy permits downloads, wrapper Maven is cached under your user profile, not installed system-wide.
Configure MongoDB if needed:
```powershell
$env:MONGODB_URI = "mongodb://localhost:27017/nmb_whatsapp_demo"
```
Use only an IT-approved database endpoint. Never commit credentials.

## IntelliJ IDEA
1. Open the extracted folder.
2. Open `pom.xml` and choose **Add as Maven Project**.
3. Select an approved JDK (project targets Java 21).
4. Run `validate`, `test`, or `spring-boot:run` from the Maven tool window.
5. If downloads are blocked, stop and request an approved Maven runtime/network access from IT.

## Demo authentication
Username: `demo-customer`
Password: `demo-only-change-me`

Most `/api/v1/**` endpoints require HTTP Basic authentication; `/api/v1/demo/info` and `/actuator/health` are public.

## Endpoints
- `GET /actuator/health`
- `GET /api/v1/demo/info`
- `POST /api/v1/demo/conversation` body: `{"message":"hello","language":"en"}`
- `GET /api/v1/demo/accounts`
- `GET /api/v1/demo/accounts/DEMO-1001`

PowerShell example:
```powershell
$pair = "demo-customer:demo-only-change-me"
$encoded = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes($pair))
$headers = @{ Authorization = "Basic $encoded" }
Invoke-RestMethod http://localhost:8080/api/v1/demo/accounts -Headers $headers
```

## Prototype limitations
The sample accounts are seeded into MongoDB. The conversation endpoint is a simple mock. No transfers, transaction authentication, fraud engine, reconciliation, Meta webhook signature validation, or real bank integration are implemented. Production requires bank authorization, security/compliance reviews, and approved infrastructure.
