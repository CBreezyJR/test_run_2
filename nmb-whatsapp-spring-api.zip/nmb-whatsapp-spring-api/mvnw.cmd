@echo off
setlocal
set "MV=3.9.9"
set "WD=%USERPROFILE%\.m2\wrapper\dists\nmb-script-wrapper\apache-maven-%MV%"
set "EXE=%WD%\apache-maven-%MV%\bin\mvn.cmd"
set "ZIP=%WD%\apache-maven-%MV%-bin.zip"
set "URL=https://repo.maven.apache.org/maven2/org/apache/maven/apache-maven/%MV%/apache-maven-%MV%-bin.zip"
if exist "%EXE%" goto run
echo This wrapper may download Maven %MV% on first use. Follow company IT policy.
if not exist "%WD%" mkdir "%WD%"
powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri '%URL%' -OutFile '%ZIP%'"
if errorlevel 1 goto fail
powershell -NoProfile -Command "Expand-Archive -LiteralPath '%ZIP%' -DestinationPath '%WD%' -Force"
if errorlevel 1 goto fail
del "%ZIP%" >nul 2>&1
if not exist "%EXE%" goto fail
:run
call "%EXE%" %*
exit /b %ERRORLEVEL%
:fail
echo Maven bootstrap failed. Check network access and company policy, or ask IT for an approved Maven runtime.
exit /b 1
