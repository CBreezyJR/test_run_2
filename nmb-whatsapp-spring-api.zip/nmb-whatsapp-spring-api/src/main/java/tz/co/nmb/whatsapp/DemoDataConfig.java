package tz.co.nmb.whatsapp;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import java.math.BigDecimal;
@Configuration
public class DemoDataConfig {
 @Bean CommandLineRunner seed(DemoAccountRepository repo) { return args -> {
  if (repo.count()==0) {
   repo.save(new DemoAccount("DEMO-1001","Demo Customer","TZS",new BigDecimal("1250000.00")));
   repo.save(new DemoAccount("DEMO-1002","Demo Savings","TZS",new BigDecimal("400000.00")));
  }
 }; }
}
