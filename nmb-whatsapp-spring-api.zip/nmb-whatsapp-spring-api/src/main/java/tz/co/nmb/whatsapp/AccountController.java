package tz.co.nmb.whatsapp;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;
@RestController
@RequestMapping("/api/v1/demo/accounts")
public class AccountController {
 private final DemoAccountRepository repo;
 public AccountController(DemoAccountRepository repo) { this.repo=repo; }
 @GetMapping public List<DemoAccount> all() { return repo.findAll(); }
 @GetMapping("/{id}") public DemoAccount one(@PathVariable String id) {
  return repo.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,"Demo account not found"));
 }
}
