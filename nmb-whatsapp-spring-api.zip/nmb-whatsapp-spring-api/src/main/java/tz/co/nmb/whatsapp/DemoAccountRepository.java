package tz.co.nmb.whatsapp;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface DemoAccountRepository extends MongoRepository<DemoAccount, String> {}
