package tz.co.nmb.whatsapp;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class NmbWhatsAppApiApplication {
 public static void main(String[] args) { SpringApplication.run(NmbWhatsAppApiApplication.class, args); }
}
