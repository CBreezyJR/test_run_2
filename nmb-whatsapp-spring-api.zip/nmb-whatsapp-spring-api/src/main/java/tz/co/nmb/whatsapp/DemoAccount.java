package tz.co.nmb.whatsapp;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.math.BigDecimal;
@Document("demo_accounts")
public record DemoAccount(@Id String accountId, String displayName, String currency, BigDecimal availableBalance) {}
