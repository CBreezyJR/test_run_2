package tz.co.nmb.whatsapp;
import org.springframework.web.bind.annotation.*;
import java.util.Map;
@RestController
@RequestMapping("/api/v1/demo")
public class DemoController {
 @GetMapping("/info") public Map<String,Object> info() {
  return Map.of("application","NMB WhatsApp Banking API Demo","mode","MOCK_ONLY","liveBankingEnabled",false,"whatsappCloudApiEnabled",false,"notice","Fictional test data only; no real transactions.");
 }
 @PostMapping("/conversation") public Map<String,String> chat(@RequestBody ChatRequest r) {
  String m=r.message()==null?"":r.message().trim().toLowerCase();
  String reply=switch(m) {
   case "hello","hi" -> "Habari! Welcome to the NMB WhatsApp Banking demo.";
   case "habari" -> "Habari! Huu ni mfano wa majaribio tu.";
   case "accounts" -> "Use the authenticated demo accounts endpoint to view fictional accounts.";
   case "transfer" -> "Transfers are simulated only. No real money moves.";
   default -> "Try: hello, habari, accounts, transfer.";
  };
  return Map.of("reply",reply,"mode","MOCK_ONLY");
 }
 public record ChatRequest(String message,String language) {}
}
